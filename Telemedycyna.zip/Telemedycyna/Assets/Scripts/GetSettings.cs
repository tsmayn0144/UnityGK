﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System;



public class GetSettings : MonoBehaviour {

    public Button startButton;
    public InputField dotSize, dotSpeed, steps, squareSize;
    public GameObject tekst;
    public Text text;

    // Use this for initialization
    void Start() {
        Button btn = startButton.GetComponent<Button>();
        //napis z błędem wartości jest chowany
        tekst.SetActive(false);
        //przy pomocy tej funkcji nasłuchuje czy przycisk został wciśnięty, jeśli tak
        //to sprawdzam dane pod przyciskiem i przesyłam je do rejestru,
        btn.onClick.AddListener(TaskOnClick);
    }

    //obsługa błedu 
    void TaskOnClick()
        {
        //jesli dane zostały poprawnie uzupełnione, program przenosi do kolejnej formatki
        if (dotSize.text != "" && dotSpeed.text != "" && steps.text != "" && squareSize.text !="")
        {
            if (Int32.Parse(dotSize.text) > 0 && Int32.Parse(dotSpeed.text) > 0 && Int32.Parse(steps.text) > 0) 
            {
                //pobranie i ustawienie wartosci w rejestrze
                PlayerPrefs.SetInt("SquareSize", Int32.Parse(squareSize.text));
                PlayerPrefs.SetInt("DotSize", Int32.Parse(dotSize.text));
                PlayerPrefs.SetInt("DotSpeed", Int32.Parse(dotSpeed.text));
                PlayerPrefs.SetInt("Steps", Int32.Parse(steps.text));
                //załadowanie formatki z badaniem

                SceneManager.LoadScene("GameScene", LoadSceneMode.Single);
            }
            else
            {
                text.text = "Podaj wartości większe od zera";
                tekst.SetActive(true);
            }
        }
        else
        {
            //napis z błędem wartości staje sie aktywny
            tekst.SetActive(true);
        }     
    }

    private void Update()
    {
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }
}
