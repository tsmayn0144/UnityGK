﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Circle_sciript : MonoBehaviour {


    public int fails = 0;
    public int speed = 5; // prędkość koła
    public int steps = 5; // ilość zmian kierunku
    public int size = 7; // wielkość koła
    public Vector2 target; // wektor współrzędnych nastepnego celu koła
    public GameObject failsTextGO;
    Text failsText;
    public bool start = true;
    //czy calkowicie wyszliscmy poza kolko
    bool outside = true;
    public GameObject square;

    // Use this for initialization
    void Start()
    {
        //odpowiada za pojawienie się ilosci błedów po skonczonym programie
        failsText = failsTextGO.GetComponent<Text>();
        //pobiera ustawienia kulki
        size = PlayerPrefs.GetInt("DotSize");
        steps = PlayerPrefs.GetInt("Steps");
        speed = PlayerPrefs.GetInt("DotSpeed");

        //ustawienie celu na poczatkowym punkcie
        target.x = transform.position.x;
        target.y = transform.position.y;
        //ustawienie rozmiaru kulki
        this.transform.localScale = new Vector3(size, size, 1);
    }

    //inny obiekt z colliderem sie rozlaczy // całkowice na zewnatrz
    private void OnTriggerExit2D(Collider2D collision)
    {
        if ((start == false) && (collision.GetType() == typeof(BoxCollider2D)))
        {
            outside = true;
            //liczba
            fails++;
        }
    }

    //inny obiekt z colliderem sie strysnie
    private void OnTriggerEnter2D(Collider2D collision)
    {

        if ((start == false) && (collision.GetType() == typeof(EdgeCollider2D)))
        {
            //nie nalicza zderzen przez rozpoaczeciem gry
            if (outside == false)
            {
                fails++;
            }
            outside = false;
        }

    }
    void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(0)) // po kliknięcu na koło wyznaczamy nowy cel i zaczyna ono podążać w tym kierunku
        {
            //po kliknięciu, kursor znika, na czas testu
            Cursor.visible = false; 
            //wyszukuje następny punkt do którego kulka się przemieści
            MoveToward();
            //zaczyna sie gra
            start = false;
        }
    }
    void MoveToward()
    {
        //odliczanie kroków - jeśli zostało steps > 0 i kulka przemieściła się do nastepnego x i y
        if (steps > 0 && (target.x == transform.position.x) && (target.y == transform.position.y))
        {
            steps--;

            //ustawienie długość ruchu kulki - z tego zakresu kulka maksymalnie sie przemiesci
            target.x = Random.Range(-19, 19);
            target.y = Random.Range(-14, 14);
        }
        //odliczanie kroków - jeśli zostało steps = 0 i kulka przemieściła się do nastepnego x i y
        if (steps == 0 && (target.x == transform.position.x) && (target.y == transform.position.y)) 
        {
            //przestanie sie ruszac
            target = this.transform.position;
            //przywracamy kursor oraz chowamy kwadrat
            Cursor.visible = true; 
            //wyłączenie podświetlonego kwadratu
            square.SetActive(false);

            //wypisanie ilości błędów po skończonym badaniu
            failsText.text = "Liczba błędnych odcinków trajektorii: " + fails;
            //włączenie podświetlenia pola tekstowego z iloscia błedów
            failsTextGO.SetActive(true);
        }
    }
    // Update is called once per frame
    private void Update()
    {
        //jeśli kulka doszła do wyznaczonego miejsca i program nadal dziala to losuje kolejny ruch
        if ((target.x == transform.position.x) && (target.y == transform.position.y) && start == false)
        {
            MoveToward();
        }
        //animacja obiektu param(x,y,czas)
        //animacja kola parametry(aktualna pozycja, nastepna pozycja, czas)
        transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }       
}
