﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquareScript : MonoBehaviour {

    public float size, dotSize, squareSize;
	// Use this for initialization
	void Start () {
        //pobiera wartosc rozmiaru wczesniej wpisane w menu
        dotSize = PlayerPrefs.GetInt("DotSize");
        squareSize = PlayerPrefs.GetInt("SquareSize");
        size = dotSize * (1 + (squareSize / 10));
        //nadanie rozmiaru kwadrata 
        //dodatkowo tutaj mozna manipolować jego rozmiarem, domysla wartosc to 1.5*rozKulki
        this.transform.localScale = new Vector3(size, size, 1);      
    }

    // Update is called once per frame
    void Update () {
        //konwertuje pozycje myszki na pozycje w grze
        Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //ustawienie pozycji kwadratu z pozycji kursora myszki
        this.transform.position = new Vector3(mousePosition.x,mousePosition.y,1);
	}
}
